module.exports = {
    user : 'User',
    admin : 'Admin'
}
